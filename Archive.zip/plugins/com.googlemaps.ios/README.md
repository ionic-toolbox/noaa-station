# Google Maps SDK for iOS for Cordova

This plugin installs Google Maps SDK for iOS (v2.1.1) into your project **without CocoaPods**.

This plugin is experimental.
